name = 'Hackerrr'
print(name + "\x00"*2 + "A+")