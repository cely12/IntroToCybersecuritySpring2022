import http.client
import urllib.parse
import sys
from pymd5 import md5, padding

if len(sys.argv) != 2:
    print('Requires the URL to extend as a command line argument.')
    exit(1)
original_url = sys.argv[1]
original_token = original_url[original_url.find("=")+1:original_url.find("&")]
original_query = original_url[original_url.find("&")+1:]
malicious_extension = '&command3=DeleteAllFiles'
original_message_length = len(original_query) + 8
message_padding = padding(original_message_length*8)
total_message_length = (original_message_length + len(message_padding))*8
h = md5(state=bytes.fromhex(original_token), count=total_message_length)
h.update(malicious_extension.encode())
updated_token = h.hexdigest()
url_safe_padding = urllib.parse.quote(message_padding)
updated_query = updated_token + '&' + original_query + url_safe_padding + malicious_extension
new_url = 'https://csci3403.com/proj1/api?token={}'.format(updated_query)
# The following code requests the URL and returns the response from
# the server
parsed_url = urllib.parse.urlparse(new_url)
conn = http.client.HTTPSConnection(parsed_url.hostname,
parsed_url.port)
conn.request("GET", parsed_url.path + "?" + parsed_url.query)
print(conn.getresponse().read())